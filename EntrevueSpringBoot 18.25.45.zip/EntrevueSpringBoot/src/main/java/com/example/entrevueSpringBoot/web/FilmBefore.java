package com.example.entrevueSpringBoot.web;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@RestController
public class FilmBefore {
	
//	@GetMapping
//	public String testingRestg(@RequestParam String id) {
//		return "lleve";
//	}
	
//	@GetMapping
//	@ResponseBody
//	public String testingRestg(@RequestParam String id) {
//		return "lleve";
//	}
}
